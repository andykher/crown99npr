# GitHub Pages 部署指南（初学者版）

本指南将教你如何把这个品牌链接页上传到 GitHub 并通过 GitHub Pages 免费发布上线。

---

## 第一步：注册 GitHub 账号

如果你还没有 GitHub 账号，请前往 [https://github.com/signup](https://github.com/signup) 注册一个免费账号。注册过程只需要邮箱和密码，非常简单。

---

## 第二步：下载项目文件

1. 在 Manus 网站上找到你的项目，点击右上角的 **Download as ZIP** 按钮（在 ⋯ 更多菜单里）
2. 将下载的 ZIP 文件解压到你电脑上的一个文件夹中，比如桌面上的 `my-link-page` 文件夹

---

## 第三步：在 GitHub 上创建新仓库

1. 登录 GitHub 后，点击右上角的 **+** 号，选择 **New repository**
2. 在 **Repository name** 中输入一个名字，比如 `my-link-page`
3. 选择 **Public**（公开），因为 GitHub Pages 免费版需要公开仓库
4. **不要**勾选 "Add a README file" 等选项，直接点击 **Create repository**
5. 创建完成后你会看到一个页面，上面有一些命令行指令，暂时不用管它

---

## 第四步：安装 GitHub Desktop（推荐初学者使用）

GitHub Desktop 是一个图形界面的 Git 工具，比命令行更友好。

1. 前往 [https://desktop.github.com/](https://desktop.github.com/) 下载 GitHub Desktop
2. 安装后打开，用你的 GitHub 账号登录
3. 点击 **File → New Repository...**
4. 选择你解压项目文件的文件夹（比如 `my-link-page`）
5. 填写仓库名称，点击 **Create repository**
6. 然后点击 **Publish repository** 将仓库上传到 GitHub
   - 确保勾选 **Keep this code private** 是 **取消勾选** 的（因为需要公开仓库才能用免费的 GitHub Pages）

---

## 第五步：配置 GitHub Pages

1. 在 GitHub 网站上打开你刚创建的仓库
2. 点击 **Settings**（设置标签页）
3. 在左侧菜单找到 **Pages**
4. 在 **Source** 下拉菜单中选择 **GitHub Actions**
5. 这个项目已经包含了自动部署的配置文件（`.github/workflows/deploy.yml`），每次你推送代码时它会自动构建并发布

> **注意**：如果你选择 **Deploy from a branch** 方式，请选择 `main` 分支和 `/ (root)` 文件夹，然后点击 **Save**。但推荐使用 GitHub Actions 方式，因为本项目需要构建步骤。

---

## 第六步：等待部署完成

1. 在仓库页面点击 **Actions** 标签页
2. 你会看到一个正在运行的工作流（叫做 "Deploy to GitHub Pages"）
3. 等待它变成绿色对勾（通常需要 1-2 分钟）
4. 部署完成后，回到 **Settings → Pages**，你会看到页面顶部显示了一个网址，格式类似：
   ```
   https://你的用户名.github.io/my-link-page/
   ```
5. 点击这个链接，你的品牌链接页就上线了！

---

## 第七步：绑定你自己的域名

你提到已经有了自己的域名，下面是绑定步骤：

1. 在 GitHub 仓库的 **Settings → Pages** 页面
2. 在 **Custom domain** 输入框中填入你的域名（比如 `www.mybrand.com`）
3. 点击 **Save**
4. 前往你的域名注册商网站（如 GoDaddy、Namecheap、Cloudflare 等）
5. 添加以下 DNS 记录：

   | 类型 | 名称/主机 | 值 |
   |------|-----------|-----|
   | A | @ | 185.199.108.153 |
   | A | @ | 185.199.109.153 |
   | A | @ | 185.199.110.153 |
   | A | @ | 185.199.111.153 |
   | CNAME | www | 你的用户名.github.io |

6. 等待 DNS 生效（通常几分钟到几小时）
7. 回到 GitHub Pages 设置页面，勾选 **Enforce HTTPS**（建议勾选，更安全）
8. 访问你的域名，页面就上线了

---

## 如何修改页面内容

所有页面内容都在 `client/src/config.ts` 文件中。你只需要修改这一个文件：

| 想修改的内容 | 在 config.ts 中找到 | 修改方式 |
|-------------|---------------------|---------|
| 浏览器标签页标题 | `pageTitle` | 改成你的品牌名 |
| 背景图片 | `backgroundImage` | 替换为你的图片 URL |
| 背景颜色 | `backgroundColor` | 改成十六进制颜色码 |
| Logo 图片 | `logoImage` | 替换为你的 Logo URL |
| 品牌名称 | `brandName` | 改成你的品牌名 |
| 标语 | `tagline` | 改成你的口号 |
| 公司介绍 | `description` | 改成你的介绍文字 |
| 主题色 | `accentColor` | 改成你的品牌色 |
| 主按钮 | `primaryButton` | 改文字和链接 |
| Telegram 链接 | `socialLinks` | 改 URL 为你的 Telegram |
| 其他社交链接 | `socialLinks` | 添加或删除条目 |
| 介绍卡片 | `infoCards` | 修改标题、内容、按钮 |
| 页脚文字 | `footerText` | 改成你的版权信息 |

修改完成后，在 GitHub Desktop 中：
1. 你会看到文件变更出现在左侧
2. 在底部填写一个简短的说明（比如 "更新品牌信息"）
3. 点击 **Commit to main**
4. 点击 **Push origin** 推送到 GitHub
5. GitHub Actions 会自动重新部署，大约 1-2 分钟后刷新网页即可看到更新

---

## 如何替换背景图片

有两种方式：

### 方式一：使用网络图片（最简单）
把你的背景图上传到任何图床服务（如 [imgur](https://imgur.com)），获取图片 URL，然后在 `config.ts` 中替换 `backgroundImage` 的值。

### 方式二：使用本地图片
1. 将背景图放入 `client/public/` 文件夹中（比如命名为 `bg.jpg`）
2. 在 `config.ts` 中将 `backgroundImage` 改为 `"/bg.jpg"`
3. 提交并推送代码即可

---

## 如何替换 Logo

和背景图片类似：

### 方式一：使用网络图片
获取你的 Logo 图片 URL，替换 `config.ts` 中的 `logoImage` 值。

### 方式二：使用本地图片
1. 将 Logo 文件放入 `client/public/` 文件夹中（比如命名为 `logo.png`）
2. 在 `config.ts` 中将 `logoImage` 改为 `"/logo.png"`

---

## 常见问题

**Q: 部署后页面空白？**
A: 检查 GitHub Actions 是否构建成功。点击仓库的 **Actions** 标签查看是否有红色错误。

**Q: 图片不显示？**
A: 确保图片 URL 是公开可访问的。如果是本地图片，确保放在 `client/public/` 文件夹中。

**Q: 域名访问不了？**
A: DNS 生效可能需要一些时间，请等待几分钟到几小时后再试。也可以用 `nslookup 你的域名` 检查 DNS 是否已生效。

**Q: 修改后没有更新？**
A: 确保在 GitHub Desktop 中先 **Commit** 再 **Push**，然后等待 GitHub Actions 重新构建完成。

---

## 需要帮助？

如果你在部署过程中遇到问题，可以：
1. 查看 GitHub Pages 官方文档：[https://docs.github.com/en/pages](https://docs.github.com/en/pages)
2. 在 GitHub Community 论坛提问：[https://github.com/orgs/community/discussions](https://github.com/orgs/community/discussions)
