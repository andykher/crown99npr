/**
 * InfoCard — 可展开/收起的介绍卡片
 * Design: Glassmorphism Dark — 半透明毛玻璃卡片，品牌色强调
 */
import { useState, useRef, useEffect } from "react";

interface InfoCardProps {
  title: string;
  content: string;
  buttonText: string;
  buttonUrl: string;
  accentColor: string;
  index: number;
}

export default function InfoCard({
  title,
  content,
  buttonText,
  buttonUrl,
  accentColor,
  index,
}: InfoCardProps) {
  const [expanded, setExpanded] = useState(false);
  const contentRef = useRef<HTMLDivElement>(null);
  const [height, setHeight] = useState(0);

  useEffect(() => {
    if (contentRef.current) {
      setHeight(expanded ? contentRef.current.scrollHeight : 0);
    }
  }, [expanded]);

  return (
    <div
      className="rounded-2xl overflow-hidden border border-white/10 backdrop-blur-md bg-white/5 transition-all duration-300"
      style={{
        animation: `fadeUp 0.5s ease-out ${0.3 + index * 0.1}s both`,
      }}
    >
      {/* 卡片标题按钮 */}
      <button
        onClick={() => setExpanded(!expanded)}
        className="w-full flex items-center justify-between px-5 py-4 text-left transition-colors hover:bg-white/5"
      >
        <span className="font-semibold text-white text-base">{title}</span>
        <svg
          className={`w-5 h-5 text-white/60 transition-transform duration-300 ${
            expanded ? "rotate-180" : ""
          }`}
          viewBox="0 0 24 24"
          fill="none"
          stroke="currentColor"
          strokeWidth="2"
          strokeLinecap="round"
          strokeLinejoin="round"
        >
          <polyline points="6 9 12 15 18 9" />
        </svg>
      </button>

      {/* 可展开内容 */}
      <div
        className="transition-all duration-300 ease-out overflow-hidden"
        style={{ maxHeight: `${height}px` }}
      >
        <div ref={contentRef} className="px-5 pb-5">
          <p className="text-white/70 text-sm leading-relaxed mb-4">{content}</p>
          <a
            href={buttonUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium text-white transition-all hover:opacity-90 active:scale-95"
            style={{
              backgroundColor: accentColor,
            }}
          >
            {buttonText}
            <svg className="w-4 h-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <line x1="7" y1="17" x2="17" y2="7" />
              <polyline points="7 7 17 7 17 17" />
            </svg>
          </a>
        </div>
      </div>
    </div>
  );
}
