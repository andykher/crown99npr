/**
 * ============================================================
 *  品牌链接主页 — 配置文件
 * ============================================================
 *  这是唯一需要修改的文件！
 *  把下面的内容替换成你自己的信息即可。
 *  保存后页面会自动更新。
 * ============================================================
 */

export const siteConfig = {
  /** 网站标题（显示在浏览器标签页上） */
  pageTitle: "My Brand Official Website",

  /** 背景图片 URL（留空则使用纯色背景） */
  backgroundImage: "/manus-storage/bg-default_61966550.jpg",

  /** 纯色背景色（当没有背景图时使用，或作为背景图的底色） */
  backgroundColor: "#0a0a1a",

  /** Logo 图片 URL（建议正方形，留空则显示品牌名首字母） */
  logoImage: "/manus-storage/logo-placeholder_26fcceda.png",

  /** 品牌名称（显示在 Logo 下方） */
  brandName: "My Brand",

  /** 品牌标语（一句话简介） */
  tagline: "Official Platform • Fast • Secure • Trusted",

  /** 公司/品牌详细介绍 */
  description:
    "We provide premium services with fast transactions, secure operations, exciting promotions, and professional customer support available 24/7.",

  /** 品牌强调色（按钮、链接等的主题色，用十六进制颜色码） */
  accentColor: "#3B82F6",

  /** 主要 CTA 按钮 */
  primaryButton: {
    text: "Visit Official Website",
    url: "https://example.com",
  },

  /** 社交链接按钮列表 */
  socialLinks: [
    {
      label: "My Telegram",
      url: "https://t.me/yourusername",
      icon: "telegram" as const,
    },
    {
      label: "My Facebook",
      url: "https://facebook.com/yourpage",
      icon: "facebook" as const,
    },
    {
      label: "My Instagram",
      url: "https://instagram.com/yourusername",
      icon: "instagram" as const,
    },
  ],

  /** 可展开的介绍卡片列表 */
  infoCards: [
    {
      title: "About Us",
      content:
        "Experience premium service with fast deposits, instant withdrawals, secure transactions, exciting promotions, and professional customer support available 24/7. Tap the button below to start your journey today.",
      buttonText: "Learn More",
      buttonUrl: "https://example.com/about",
    },
    {
      title: "VIP Membership",
      content:
        "Join our VIP program to enjoy exclusive rewards, higher limits, and priority support.",
      buttonText: "Join VIP",
      buttonUrl: "https://example.com/vip",
    },
  ],

  /** 页脚文字 */
  footerText: "© 2026 My Brand. All rights reserved.",
};

export type SiteConfig = typeof siteConfig;
