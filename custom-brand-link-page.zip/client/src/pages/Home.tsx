/**
 * Home — 品牌链接主页
 * Design: Glassmorphism Dark
 *
 * 这是一个 link-in-bio 风格的单页网站。
 * 所有内容都通过 config.ts 配置，无需修改此文件。
 * 只需编辑 client/src/config.ts 即可自定义你的页面。
 */
import { siteConfig } from "@/config";
import SocialIcon from "@/components/SocialIcon";
import InfoCard from "@/components/InfoCard";

export default function Home() {
  const {
    pageTitle,
    backgroundImage,
    backgroundColor,
    logoImage,
    brandName,
    tagline,
    description,
    accentColor,
    primaryButton,
    socialLinks,
    infoCards,
    footerText,
  } = siteConfig;

  return (
    <div
      className="min-h-screen flex flex-col items-center px-4 py-10 sm:py-16 relative"
      style={{
        backgroundColor: backgroundColor,
        backgroundImage: backgroundImage ? `url(${backgroundImage})` : undefined,
        backgroundSize: "cover",
        backgroundPosition: "center",
        backgroundAttachment: "fixed",
      }}
    >
      {/* 背景遮罩层 — 让内容更清晰 */}
      <div
        className="absolute inset-0 pointer-events-none"
        style={{
          background: `linear-gradient(to bottom, ${backgroundColor}cc, ${backgroundColor}99, ${backgroundColor}cc)`,
        }}
      />

      {/* 主内容容器 */}
      <div className="relative z-10 w-full max-w-md flex flex-col items-center gap-6">
        {/* Logo */}
        <div
          className="w-24 h-24 rounded-2xl overflow-hidden border border-white/20 shadow-2xl backdrop-blur-md"
          style={{ animation: "fadeUp 0.6s ease-out both" }}
        >
          {logoImage ? (
            <img
              src={logoImage}
              alt={brandName}
              className="w-full h-full object-cover"
            />
          ) : (
            <div
              className="w-full h-full flex items-center justify-center text-4xl font-bold text-white"
              style={{ backgroundColor: accentColor }}
            >
              {brandName.charAt(0).toUpperCase()}
            </div>
          )}
        </div>

        {/* 品牌名称 */}
        <h1
          className="text-2xl font-bold text-white text-center"
          style={{ animation: "fadeUp 0.6s ease-out 0.1s both" }}
        >
          {pageTitle}
        </h1>

        {/* 标语 */}
        <p
          className="text-white/70 text-sm text-center font-medium italic"
          style={{ animation: "fadeUp 0.6s ease-out 0.2s both" }}
        >
          {tagline}
        </p>

        {/* 描述 */}
        <p
          className="text-white/60 text-sm text-center leading-relaxed max-w-sm"
          style={{ animation: "fadeUp 0.6s ease-out 0.25s both" }}
        >
          {description}
        </p>

        {/* 主要 CTA 按钮 */}
        <a
          href={primaryButton.url}
          target="_blank"
          rel="noopener noreferrer"
          className="w-full max-w-sm px-6 py-4 rounded-2xl text-center font-semibold text-white transition-all hover:scale-[1.02] active:scale-[0.98] shadow-lg"
          style={{
            backgroundColor: accentColor,
            boxShadow: `0 4px 20px ${accentColor}40`,
            animation: "fadeUp 0.6s ease-out 0.3s both",
          }}
        >
          {primaryButton.text}
        </a>

        {/* 介绍卡片列表 */}
        <div className="w-full max-w-sm flex flex-col gap-3 mt-2">
          {infoCards.map((card, index) => (
            <InfoCard
              key={index}
              title={card.title}
              content={card.content}
              buttonText={card.buttonText}
              buttonUrl={card.buttonUrl}
              accentColor={accentColor}
              index={index}
            />
          ))}
        </div>

        {/* 社交链接按钮 */}
        <div className="w-full max-w-sm flex flex-col gap-3 mt-2">
          {socialLinks.map((link, index) => (
            <a
              key={index}
              href={link.url}
              target="_blank"
              rel="noopener noreferrer"
              className="w-full flex items-center justify-center gap-3 px-6 py-3.5 rounded-2xl text-white font-medium border border-white/15 backdrop-blur-md bg-white/10 transition-all hover:bg-white/15 hover:scale-[1.02] active:scale-[0.98]"
              style={{
                animation: `fadeUp 0.5s ease-out ${0.4 + index * 0.08}s both`,
              }}
            >
              <SocialIcon type={link.icon} className="w-5 h-5" />
              <span>{link.label}</span>
            </a>
          ))}
        </div>

        {/* 页脚 */}
        <p
          className="text-white/40 text-xs text-center mt-6"
          style={{ animation: "fadeUp 0.6s ease-out 0.8s both" }}
        >
          {footerText}
        </p>
      </div>
    </div>
  );
}
