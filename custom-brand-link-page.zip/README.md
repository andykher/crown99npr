# 品牌链接主页 (Brand Link Page)

一个可自定义的品牌链接单页网站，类似 [heylink.me](https://heylink.me) 或 Linktree。支持自定义背景、Logo、公司介绍、Telegram 链接和其他社交链接。可免费部署到 GitHub Pages。

## 特性

- 自定义背景图片或纯色背景
- 自定义 Logo、品牌名称、标语和公司介绍
- 可展开的介绍卡片
- Telegram、Facebook、Instagram 等社交链接按钮
- 主要 CTA 按钮
- 响应式设计，移动端优先
- 玻璃拟态 (Glassmorphism) 深色风格
- 一键部署到 GitHub Pages

## 快速开始

### 本地开发

```bash
pnpm install
pnpm dev
```

浏览器打开 `http://localhost:3000` 即可预览。

### 自定义内容

**只需修改一个文件：** `client/src/config.ts`

在这个文件中你可以修改：
- 页面标题、品牌名称、标语
- 背景图片和颜色
- Logo
- 公司介绍文字
- 主题色
- 主按钮文字和链接
- 社交链接（Telegram、Facebook、Instagram 等）
- 介绍卡片内容
- 页脚文字

### 部署到 GitHub Pages

请阅读 [GITHUB-PAGES-GUIDE.md](./GITHUB-PAGES-GUIDE.md) 获取详细的初学者部署指南。

## 技术栈

- React 19
- TypeScript
- Tailwind CSS 4
- Vite 7
