# 品牌链接主页 — 设计头脑风暴

## 参考页面分析
用户参考了 heylink.me/pokeslot8，一个典型的 link-in-bio 单页：
- 深色背景 + 图案纹理
- 居中 Logo / 标题 / 简介
- 可展开的链接卡片
- Telegram、Facebook 等社交按钮
- 底部 CTA 按钮

## 三种设计方向

### 1. 暗夜霓虹 (Dark Neon)
深黑背景 + 霓虹紫蓝渐变光晕，赛博朋克风格。
Probability: 0.07

### 2. 极简卡片 (Minimal Card)
纯白背景 + 单一品牌色点缀，大量留白，瑞士风排版。
Probability: 0.04

### 3. 玻璃拟态深色 (Glassmorphism Dark)
深色可定制背景图 + 毛玻璃半透明卡片，柔和光晕，优雅渐变。
Probability: 0.09

## 选定方向：玻璃拟态深色 (Glassmorphism Dark)

**Design Movement**: Glassmorphism — 毛玻璃质感 + 深色背景图层叠

**Core Principles**:
1. 背景可替换：用户通过配置文件替换背景图 URL
2. 内容居中卡片：所有内容放在一个毛玻璃卡片内，移动端友好
3. 层次分明：Logo → 标题 → 简介 → 链接按钮 → CTA，自上而下清晰节奏
4. 微交互：按钮 hover 光晕、卡片展开动画、入场淡入

**Color Philosophy**:
- 背景层：深色（用户可替换图片或纯色）
- 卡片层：半透明白色毛玻璃 `rgba(255,255,255,0.08)` + `backdrop-blur`
- 文字层：白色为主，次级文字 `rgba(255,255,255,0.7)`
- 强调色：用户可配置的品牌色（默认电光蓝 `#3B82F6`）

**Layout Paradigm**:
- 单列居中布局，最大宽度 480px，移动端优先
- 这符合 link-in-bio 的使用场景（手机扫码访问）

**Signature Elements**:
1. 毛玻璃卡片容器
2. 品牌色光晕按钮
3. 顶部 Logo 圆角方形

**Interaction Philosophy**:
- 按钮按下缩放反馈 `scale(0.97)`
- 卡片展开/收起平滑过渡
- 入场动画级联淡入

**Animation**:
- 入场：卡片从 `opacity:0 + translateY(20px)` 淡入，级联 60ms
- 按钮 hover：品牌色光晕扩散
- 按钮按下：`scale(0.97)` + 160ms ease-out

**Typography System**:
- 标题：Plus Jakarta Sans 700
- 正文：Plus Jakarta Sans 400
- 次级文字：Plus Jakarta Sans 500 + 70% 透明度

**Brand Essence**: 一个让任何人都能 5 分钟内搭建专属品牌链接页的工具，面向想要专业在线形象的个体和小团队。
Personality: 专业、简洁、可信赖

**Brand Voice**:
- 标题示例："Your Brand Official Website"
- CTA 示例："Visit Now"
- 不用 "Welcome to our website" 这类套话

**Wordmark & Logo**: 用户可替换的圆角方形 Logo 占位符

**Signature Brand Color**: `#3B82F6` (电光蓝，用户可配置)
